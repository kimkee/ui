# 1.3.0

- Removed Gulp.
- Added Spanish language as 'es' lang code.
- Fixed marging after the day section in some cases.

## 1.2.3

- Added Polish language.
- Updated jQuery dependency to a latest version and made it as peer.
